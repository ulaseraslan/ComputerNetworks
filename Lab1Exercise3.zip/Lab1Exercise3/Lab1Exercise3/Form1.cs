﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1Exercise3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Connect_Click(object sender, EventArgs e)
        {
            string id = idBox.Text;
            string pass = passBox.Text;

            if (id == "" && pass == "") {
                Connect.BackColor = Color.Red;
            }
            else
            {
                Connect.BackColor = Color.Green;

                Connect.Enabled = false;
                DC.Enabled = true;
                richTextBox1.Enabled = true;
                textBoxSend.Enabled = true;
                SendButton.Enabled = true;
            }

        }

        private void DC_Click(object sender, EventArgs e)
        {
            DC.Enabled = false;
            Connect.Enabled = true;
            Connect.BackColor = Color.Transparent;
            richTextBox1.Enabled = false;
            textBoxSend.Enabled = false;
            SendButton.Enabled = false;

        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            string id = idBox.Text;
            string message = textBoxSend.Text;

            richTextBox1.Text = id + " " + message + "\n";
            textBoxSend.Clear();
        }
    }
}
