﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Lab2Exercise1
{
    public partial class Form1 : Form
    {

        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //Socket Object
        List<Socket> clientSockets = new List<Socket>(); //Client List

        bool terminating = false;
        bool listening = false;

        public Form1()
        {

            Control.CheckForIllegalCrossThreadCalls = false; // To close the connection when "x" button is checked.
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);

            InitializeComponent();
        }

        private void Form1_FormClosing (object sender, System.ComponentModel.CancelEventArgs e) // Helper function to exit 
        {
            listening = false;
            terminating = true;
            Environment.Exit(0);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void ListenButton_Click(object sender, EventArgs e)
        {
            int port;

            if(Int32.TryParse(textBox1.Text,out port))
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, port); // Create an endpoint like 127.0.0.1:port (IPAddress+port) 
                serverSocket.Bind(endPoint); // Binding endpoint
                serverSocket.Listen(3);

                listening = true;

                ListenButton.Enabled = false;
                messageBox.Enabled = true;
                SendButton.Enabled = true;

                Thread acceptThread = new Thread(Accept); // Create a thread for accepting connections
                acceptThread.Start();
            } 
        }

        private void Accept()
        {

            while (listening)
            {
                try
                {
                    Socket newClient = serverSocket.Accept(); 
                    clientSockets.Add(newClient); // Add new client
                    richTextBox1.AppendText("A client is connected!\n");

                    Thread receiveThread = new Thread(() => Receive(newClient)); // To receive new messages create a new thread.
                    receiveThread.Start();
                }

                catch
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        richTextBox1.AppendText("The socket stopped working!");
                    }
                }
            }
        }

        private void Receive (Socket thisClient)
        {
            bool connected = true;

            while (connected && !terminating)
            {
                try
                {
                    Byte[] buffer = new byte[64]; // To convert coming message to human readable type
                    thisClient.Receive(buffer);

                    string incomingmessage = Encoding.Default.GetString(buffer);
                    incomingmessage = incomingmessage.Substring(0, incomingmessage.IndexOf("\0")); // To prevent from unmeaningful messages when text is empty
                    richTextBox1.AppendText("Client: " + incomingmessage + "\n");

                }
                catch
                {
                    if (!terminating)
                    {
                        richTextBox1.AppendText("Client has disconnected!\n");
                    }
                    thisClient.Close();
                    clientSockets.Remove(thisClient);
                    connected = false;
                    
                }
            }

        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            string message = messageBox.Text;

            if (message!= " " && message.Length<=64) // Since buffer size is 64
            {
                Byte[] buffer = Encoding.Default.GetBytes(message);

                foreach(Socket client in clientSockets) // To send the message to all clients 
                {
                    try
                    {
                        client.Send(buffer);
                    }
                    catch
                    {
                        richTextBox1.AppendText("Check the connection!\n");
                        terminating = true;
                        messageBox.Enabled = false;
                        SendButton.Enabled = false;
                        textBox1.Enabled = true;
                        ListenButton.Enabled = true;
                        serverSocket.Close();
                    }
                }
            }
        }
    }
}
