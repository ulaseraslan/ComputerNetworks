﻿
namespace Lab1Exercise
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SubmitButton = new System.Windows.Forms.Button();
            this.IceCreamCheck = new System.Windows.Forms.CheckBox();
            this.LikeCakeCheck = new System.Windows.Forms.CheckBox();
            this.ClearButton = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(90, 216);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(94, 29);
            this.SubmitButton.TabIndex = 0;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // IceCreamCheck
            // 
            this.IceCreamCheck.AutoSize = true;
            this.IceCreamCheck.Location = new System.Drawing.Point(90, 126);
            this.IceCreamCheck.Name = "IceCreamCheck";
            this.IceCreamCheck.Size = new System.Drawing.Size(127, 24);
            this.IceCreamCheck.TabIndex = 1;
            this.IceCreamCheck.Text = "Like Ice Cream";
            this.IceCreamCheck.UseVisualStyleBackColor = true;
            this.IceCreamCheck.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // LikeCakeCheck
            // 
            this.LikeCakeCheck.AutoSize = true;
            this.LikeCakeCheck.Location = new System.Drawing.Point(90, 169);
            this.LikeCakeCheck.Name = "LikeCakeCheck";
            this.LikeCakeCheck.Size = new System.Drawing.Size(93, 24);
            this.LikeCakeCheck.TabIndex = 2;
            this.LikeCakeCheck.Text = "Like Cake";
            this.LikeCakeCheck.UseVisualStyleBackColor = true;
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(204, 216);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(94, 29);
            this.ClearButton.TabIndex = 3;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(90, 272);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(208, 120);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 444);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.LikeCakeCheck);
            this.Controls.Add(this.IceCreamCheck);
            this.Controls.Add(this.SubmitButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.CheckBox IceCreamCheck;
        private System.Windows.Forms.CheckBox LikeCakeCheck;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

