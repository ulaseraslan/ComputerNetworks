﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Lab2Exercise1Client
{
    public partial class Form1 : Form       
    {
        bool terminating = false;
        bool connect = false;


        Socket clientSocket;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void Form1_FormClosing (object sender, System.ComponentModel.CancelEventArgs e)
        {
            terminating = true;
            connect = false;
            Environment.Exit(0);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void ConnectButton_Click(object sender, EventArgs e)
        {
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string IP = IpTextBox.Text;

            int portNum;

            if (Int32.TryParse(PortTextBox.Text, out portNum))
            {
                try
                {
                    clientSocket.Connect(IP, portNum);
                    ConnectButton.Enabled = false;
                    messageBox.Enabled = true;
                    SendButton.Enabled = true;
                    connect = true;
                    richTextBox1.AppendText("Connected to the server!\n");

                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();
                }

                catch
                {
                    richTextBox1.AppendText("Could not connect to the server!\n");
                }
            }
            else
            {
                richTextBox1.AppendText("Check Port Number!");
            }
        }

        private void Receive ()
        {
            while(connect) {

                try
                {
                    Byte[] buffer = new byte[64];
                    clientSocket.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                    richTextBox1.AppendText("Client:" + (incomingMessage)+ "\n");
                }
                catch
                {
                    if (!terminating)
                    {
                        richTextBox1.AppendText("Server has disconnected!\n");
                        ConnectButton.Enabled = true;
                        SendButton.Enabled = false;
                        messageBox.Enabled = false;
                    }
                    clientSocket.Close();
                    connect = false;
                }
            }
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            string message;
            message = messageBox.Text;

            if ( message != " " && message.Length<=64)
            {
                Byte[] buffer = new Byte[64];
                buffer = Encoding.Default.GetBytes(message);
                clientSocket.Send(buffer);
            }
        }
    }
}
