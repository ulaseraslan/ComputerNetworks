﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1Example2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string item;

            item = addTextBox.Text;

            listView1.Items.Add(item);
            addTextBox.Clear();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            string to_be_removed = RemoveTextBox.Text;

            foreach(ListViewItem item in listView1.Items)
            {
                if (item.Text == to_be_removed) 
                {
                    listView1.Items.Remove(item);
                }
            }

            RemoveTextBox.Clear();
        }
    }
}
